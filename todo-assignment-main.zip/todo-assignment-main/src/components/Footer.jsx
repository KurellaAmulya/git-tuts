import React from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faGithub } from '@fortawesome/free-brands-svg-icons';

const Footer = () => {
  return (
    <footer className="text-center bg-light py-4">
      <div className="d-flex align-items-center justify-content-center flex-column">
        
        
      </div>
    </footer>
  );
};

export default Footer;
